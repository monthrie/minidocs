# minidocs
1. receive message to server MAX# via maxima
2. send that message to the API
3. receive the message back
4. send the returned message to the contact address of the asker (user) via maxima
5. await further messages